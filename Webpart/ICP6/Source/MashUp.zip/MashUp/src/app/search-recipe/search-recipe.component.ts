import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Component({
  selector: 'app-search-recipe',
  templateUrl: './search-recipe.component.html',
  styleUrls: ['./search-recipe.component.css']
})
export class SearchRecipeComponent implements OnInit {
  @ViewChild('recipe') recipes: ElementRef;
  @ViewChild('place') places: ElementRef;
  recipeValue: any;
  placeValue: any;
  venueList = [];
  recipeList = [];
  currentLat: any;
  currentLong: any;
  geolocationPosition: any;

  constructor(private http: HttpClient) {
  }

  ngOnInit() {

    window.navigator.geolocation.getCurrentPosition(
      position => {
        this.geolocationPosition = position;
        this.currentLat = position.coords.latitude;
        this.currentLong = position.coords.longitude;
      });
  }
  // To get Recipe Data from Edamam API
  getRecipeData() {
    this.recipeList = [];
    this.http.get(`https://api.edamam.com/search?q=${this.recipeValue}&from=0&to=5&`
      +`app_id=a43eab2f&app_key=fadf8afd53e8d1c27996d3881486fa12`).
    subscribe((data) =>
    {
      console.log("Recipe Data",data);
      const recipeData = data['hits'];
      recipeData.forEach(recipeValue => {
        this.recipeList.push({
          name : recipeValue['recipe'].label,
          url : recipeValue['recipe'].url,
          icon: recipeValue['recipe'].image
        })
      });
      console.log("Receipe Array",this.recipeList)
    })
    return this.recipeList;
  }

  //To get Place Data from FourSquare API
  getPlaceData(){
    this.venueList = [];
    const head_HTTP = new HttpHeaders({
      Accept: 'application/json',
      Authorization: 'fsq3wQ8U88RYgxh4D/C6WDSqvZd4mwz51ho0L6CnyhdMpf8=',
    });
    this.http.get(`https://api.foursquare.com/v3/places/search?query=`
      +this.recipeValue + `&near=` + this.placeValue + '&v=20220221', {headers: head_HTTP}).
    subscribe((data) => {
      console.log("Restaurent Location data",data);
      const placeData = data['results'];
      placeData.forEach(places => {
        this.venueList.push({
          name: places.name,
          location: {
            formattedAddress: [places.location.formatted_address,
              places.location.locality, places.location.country]
          }
        });
      });
      console.log("placedata", this.venueList);
      return this.venueList;
    })
  }

  //To get venues method
  getVenues() {
    this.recipeValue = this.recipes.nativeElement.value;
    this.placeValue = this.places.nativeElement.value;
    if (this.recipeValue !== null) {
      this.getRecipeData();
    }
    if (this.placeValue != null && this.placeValue !== '' && this.recipeValue != null &&
      this.recipeValue !== '') {
      this.getPlaceData()
    }
  }
}
