//TypeScript file for ToDoList and Timer Program
import { Component, OnInit } from '@angular/core';
//Referring the components here
@Component({
  selector: 'app-icp5-web-task',
  templateUrl: './icp5-web-task.component.html',
  styleUrls: ['./icp5-web-task.component.css']
})
//Initialization
export class ICP5WebTaskComponent implements OnInit {
  public todos = [];
  public countDownTimes;
  public interval;
  public todo = '';
  public time :any;
  constructor() { }
  ngOnInit(): void {
  }
//Calculating the Event Date Time
  getCountDown(begin_time) {
    this.interval = setInterval(() => {
      const currentTime = new Date().getTime();
      const difference = begin_time.getTime() - currentTime;
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      this.countDownTimes= {
        days,
        hours,
        minutes,
        seconds
      };
    }, 1000);
  }
//startTimer function to save the countdown timer
  startTimer(){
    clearInterval(this.interval);
    this.getCountDown(new Date(this.time));
  }
//To Save the ToDoList entered by the user
  saveTodo(){
    const todoObject = {
      id: this.todos.length + 1,
      name: this.todo,
      completed: false,
    }
    this.todos.push(todoObject);
    console.log(this.todos)
  }

//To Delete the ToDoList name from the list
  removeTodo(index) {
    this.todos.splice(index,1)
    this.countDownTimes.splice(index,1)
  }
//To mark it as completed but not deleted
  toggleTodoComplete(index) {
    const todo = this.todos[index];
    todo['completed'] = !todo['completed'];
    this.todos[index] = todo;
  }
}
