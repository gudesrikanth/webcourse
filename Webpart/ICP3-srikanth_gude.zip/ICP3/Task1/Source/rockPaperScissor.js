
const rock = document.getElementById("rock");
const paper = document.getElementById("paper");
const scissor = document.getElementById("scissor") ;
const result = document.getElementById("result");

//Method to return computer's choice
function getComputerSelection(){
    const selections = ["rock","paper","scissor"]
    const index =  Math.floor(Math.random()*3)
    return selections[index]
}

//To check the state of the game
function play(userSelection){
    const computerSelection = getComputerSelection();
    switch (userSelection + computerSelection) {
        case "paperrock":
        case "rockscissors":
        case "scissopaper":
            console.log("Won");
            result.innerHTML = `You won!! Your choice is ${userSelection} and computer's choice is ${computerSelection}`;
            break;
        case "rockpaper":
        case "scissorrock":
        case "paperscissor":
            console.log("Lost");
            result.innerHTML = `You Lost!! Your choice is ${userSelection} but computer's choice is ${computerSelection}`;
            break;
        case "rockrock":
        case "scissorsscissor":
        case "paperpaper":
            console.log("Draw");
            result.innerHTML = `It is a draw!! Both of you chose ${userSelection}`;
            break;
    }
}
//To capture the user's choice
function main(){
    rock.addEventListener("click", () => play("rock"));
    paper.addEventListener("click", () => play("paper"));
    scissor.addEventListener("click",() => play("scissor"))
}
main();